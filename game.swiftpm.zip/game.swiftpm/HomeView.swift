//  HomeView.swift
//  Homepage: mountains + garden scenery, a character standing on the path
//  (waving), flowers that grow with usage, and all the main buttons.
//  Works in portrait AND landscape (one layout that rearranges itself).
//
//  DEPENDS ON (keep these files in your project):
//    - GardenColors.swift  (GardenPalette, TimeOfDay, HillLayer, Color(hex:))
//    - UsageTracker.swift  (UsageTracker)
//
//  PLACEHOLDERS you will probably change:
//    - The title "Garden Path" and the tagline
//    - Button actions: HomeView(onSelect:) tells you which button was tapped;
//      for now it does nothing. Hook it up to real screens later.
//
//  Needs iOS 17+ (uses the two-parameter onChange and #Preview traits).
//

import SwiftUI

// MARK: - Navigation targets

enum HomeDestination {
    case play, players, guide, settings
}

// MARK: - Button press feel

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

// MARK: - Character (simple shapes, one rig; skins are just colors)

struct CharacterStyle {
    var skin = Color(hex: "F2C9A0")
    var hair = Color(hex: "5A3E2B")
    var outfit = GardenPalette.accent
    var pants = Color(hex: "5B7DB1")
    var shoes = Color(hex: "403326")
}

struct Smile: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: rect.minX, y: rect.minY))
        p.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.minY),
                       control: CGPoint(x: rect.midX, y: rect.maxY * 2))
        return p
    }
}

/// An arm that can wave. Rotates around the shoulder (top of the arm).
struct ArmView: View {
    let u: CGFloat
    let style: CharacterStyle
    var waving = false
    @State private var wave = false

    var body: some View {
        ZStack(alignment: .top) {
            Capsule().fill(style.outfit)
                .frame(width: u * 0.95, height: u * 2.9)
            Circle().fill(style.skin)
                .frame(width: u * 0.9, height: u * 0.9)
                .offset(y: u * 2.3)
        }
        .frame(width: u * 0.95, height: u * 3.2, alignment: .top)
        .rotationEffect(.degrees(waving ? (wave ? -150 : -125) : 0), anchor: .top)
        .animation(.easeInOut(duration: 0.45).repeatForever(autoreverses: true), value: wave)
        .onAppear { if waving { wave = true } }
    }
}

struct CharacterView: View {
    var style = CharacterStyle()
    var height: CGFloat = 200
    var waving = true
    @State private var breathe = false

    var body: some View {
        let u = height / 10
        let dark = Color(hex: "403326")

        ZStack(alignment: .top) {
            // Legs and shoes
            Group {
                Capsule().fill(style.pants)
                    .frame(width: u, height: u * 3.4).offset(x: -u * 0.75, y: u * 6.0)
                Capsule().fill(style.pants)
                    .frame(width: u, height: u * 3.4).offset(x: u * 0.75, y: u * 6.0)
                Capsule().fill(style.shoes)
                    .frame(width: u * 1.5, height: u * 0.7).offset(x: -u * 0.85, y: u * 9.3)
                Capsule().fill(style.shoes)
                    .frame(width: u * 1.5, height: u * 0.7).offset(x: u * 0.85, y: u * 9.3)
            }

            // Left arm (resting)
            ArmView(u: u, style: style)
                .offset(x: -u * 1.75, y: u * 3.2)

            // Body
            RoundedRectangle(cornerRadius: u * 0.9)
                .fill(style.outfit)
                .frame(width: u * 3.0, height: u * 3.9)
                .offset(y: u * 2.8)

            // Right arm (waves hello)
            ArmView(u: u, style: style, waving: waving)
                .offset(x: u * 1.75, y: u * 3.2)

            // Hair, then face on top of it
            Circle().fill(style.hair)
                .frame(width: u * 3.4, height: u * 3.4).offset(y: -u * 0.2)
            Circle().fill(style.skin)
                .frame(width: u * 3.0, height: u * 3.0).offset(y: u * 0.3)

            // Eyes, cheeks, smile
            Group {
                HStack(spacing: u * 0.9) {
                    Circle().fill(dark).frame(width: u * 0.3, height: u * 0.3)
                    Circle().fill(dark).frame(width: u * 0.3, height: u * 0.3)
                }
                .offset(y: u * 1.45)

                HStack(spacing: u * 1.6) {
                    Circle().fill(Color.pink.opacity(0.35)).frame(width: u * 0.45, height: u * 0.45)
                    Circle().fill(Color.pink.opacity(0.35)).frame(width: u * 0.45, height: u * 0.45)
                }
                .offset(y: u * 1.8)

                Smile()
                    .stroke(dark, style: StrokeStyle(lineWidth: u * 0.14, lineCap: .round))
                    .frame(width: u * 0.9, height: u * 0.35)
                    .offset(y: u * 1.95)
            }
        }
        .frame(width: u * 6, height: height, alignment: .top)
        .scaleEffect(breathe ? 1.015 : 1.0, anchor: .bottom)
        .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: breathe)
        .onAppear { breathe = true }
    }
}

// MARK: - Flowers (the garden grows with usage)

struct FlowerSpot: Identifiable {
    let id: Int
    let x: CGFloat        // 0...1 across the scene
    let depth: CGFloat    // 0 = back of the path, 1 = front
    let scale: CGFloat
    let colorIndex: Int
    let duration: Double  // sway speed

    // x, depth, scale, colorIndex, duration. The first few are the ones always
    // shown; the rest appear as the player's week gets more active.
    static let all: [FlowerSpot] = {
        let raw: [(CGFloat, CGFloat, CGFloat, Int, Double)] = [
            (0.12, 0.80, 1.10, 1, 2.6), (0.45, 0.35, 0.90, 4, 2.8),
            (0.68, 0.90, 1.15, 2, 2.3), (0.90, 0.35, 0.95, 0, 2.6),
            (0.20, 0.50, 0.80, 2, 2.0), (0.60, 0.40, 0.85, 1, 2.5),
            (0.05, 0.30, 0.90, 0, 2.2), (0.82, 0.80, 1.00, 4, 2.2),
            (0.38, 0.85, 1.20, 3, 2.4), (0.75, 0.50, 0.90, 3, 2.7),
            (0.95, 0.85, 1.10, 1, 2.0), (0.52, 0.70, 1.00, 0, 2.1),
            (0.28, 0.20, 0.70, 2, 2.9), (0.58, 0.15, 0.70, 3, 2.4),
            (0.80, 0.20, 0.75, 4, 2.6), (0.15, 0.15, 0.70, 1, 2.3)
        ]
        return raw.enumerated().map {
            FlowerSpot(id: $0.offset, x: $0.element.0, depth: $0.element.1,
                       scale: $0.element.2, colorIndex: $0.element.3, duration: $0.element.4)
        }
    }()

    static let petalColors: [Color] = ["F08A6B", "F4C95D", "F7A8C4", "FFFFFF", "B79CED"].map { Color(hex: $0) }
}

struct FlowerView: View {
    let size: CGFloat
    let petal: Color
    let swayDuration: Double
    @State private var sway = false

    var body: some View {
        ZStack(alignment: .top) {
            Capsule().fill(Color(hex: "5E9A52"))
                .frame(width: size * 0.07, height: size * 0.8)
                .offset(y: size * 0.22)
            ZStack {
                ForEach(0..<6, id: \.self) { i in
                    Circle().fill(petal)
                        .frame(width: size * 0.2, height: size * 0.2)
                        .offset(y: -size * 0.11)
                        .rotationEffect(.degrees(Double(i) * 60))
                }
                Circle().fill(Color(hex: "F4C95D"))
                    .frame(width: size * 0.16, height: size * 0.16)
            }
            .frame(width: size * 0.5, height: size * 0.5)
        }
        .frame(width: size * 0.5, height: size)
        .rotationEffect(.degrees(sway ? 4 : -4), anchor: .bottom)
        .animation(.easeInOut(duration: swayDuration).repeatForever(autoreverses: true), value: sway)
        .onAppear { sway = true }
    }
}

/// Wraps a flower so it grows up from the ground when it first appears.
struct PlantedFlower: View {
    let size: CGFloat
    let petal: Color
    let swayDuration: Double
    @State private var planted = false

    var body: some View {
        FlowerView(size: size, petal: petal, swayDuration: swayDuration)
            .scaleEffect(planted ? 1 : 0.01, anchor: .bottom)
            .animation(.spring(response: 0.6, dampingFraction: 0.6), value: planted)
            .onAppear { planted = true }
    }
}

// MARK: - Scenery pieces

struct MountainShape: Shape {
    var points: [(CGFloat, CGFloat)]   // x, y as fractions 0...1 of the frame

    func path(in rect: CGRect) -> Path {
        var p = Path()
        guard let first = points.first else { return p }
        p.move(to: CGPoint(x: first.0 * rect.width, y: first.1 * rect.height))
        for pt in points.dropFirst() {
            p.addLine(to: CGPoint(x: pt.0 * rect.width, y: pt.1 * rect.height))
        }
        p.closeSubpath()
        return p
    }
}

struct MountainLayer: View {
    let color: Color
    let tint: Color
    let points: [(CGFloat, CGFloat)]

    var body: some View {
        ZStack {
            MountainShape(points: points).fill(color)
            MountainShape(points: points).fill(tint)
        }
    }
}

struct CloudView: View {
    let sceneWidth: CGFloat
    let y: CGFloat
    let scale: CGFloat
    let seconds: Double
    @State private var drift = false

    var body: some View {
        ZStack {
            Capsule().frame(width: 90, height: 28)
            Circle().frame(width: 40, height: 40).offset(x: -15, y: -14)
            Circle().frame(width: 50, height: 50).offset(x: 15, y: -18)
        }
        .foregroundStyle(Color.white.opacity(0.85))
        .scaleEffect(scale)
        .position(x: drift ? sceneWidth * 1.2 : -sceneWidth * 0.2, y: y)
        .animation(.linear(duration: seconds).repeatForever(autoreverses: false), value: drift)
        .onAppear { drift = true }
    }
}

struct SkyBody: View {
    let time: TimeOfDay
    let size: CGSize

    private let stars: [(CGFloat, CGFloat)] = [
        (0.10, 0.10), (0.25, 0.18), (0.40, 0.07), (0.55, 0.20), (0.70, 0.10),
        (0.90, 0.24), (0.15, 0.28), (0.33, 0.30), (0.62, 0.32), (0.95, 0.08)
    ]

    var body: some View {
        let d = min(size.width, size.height) * 0.14
        ZStack {
            switch time {
            case .day:
                Circle().fill(Color(hex: "FFE08A"))
                    .frame(width: d, height: d)
                    .shadow(color: Color(hex: "FFE08A").opacity(0.8), radius: d * 0.5)
                    .position(x: size.width * 0.82, y: size.height * 0.16)
            case .evening:
                Circle().fill(Color(hex: "FF9F45"))
                    .frame(width: d * 1.25, height: d * 1.25)
                    .shadow(color: Color(hex: "FF9F45").opacity(0.7), radius: d * 0.5)
                    .position(x: size.width * 0.8, y: size.height * 0.3)
            case .night:
                Circle().fill(Color(hex: "F4F1DE"))
                    .frame(width: d * 0.8, height: d * 0.8)
                    .shadow(color: Color.white.opacity(0.4), radius: d * 0.3)
                    .position(x: size.width * 0.82, y: size.height * 0.16)
                ForEach(0..<stars.count, id: \.self) { i in
                    Circle().fill(Color.white.opacity(0.8))
                        .frame(width: 4, height: 4)
                        .position(x: size.width * stars[i].0, y: size.height * stars[i].1)
                }
            }
        }
        .frame(width: size.width, height: size.height)
    }
}

// MARK: - The whole scene

struct HomeScene: View {
    let time: TimeOfDay
    let bloom: Int                 // days played this week (0...7)
    var characterX: CGFloat = 0.3  // where the character stands (0...1)

    private let flowers = FlowerSpot.all

    private var farMountains: [(CGFloat, CGFloat)] {
        [(0, 1), (0, 0.6), (0.10, 0.40), (0.20, 0.55), (0.34, 0.15), (0.48, 0.50),
         (0.60, 0.30), (0.74, 0.55), (0.88, 0.35), (1, 0.50), (1, 1)]
    }
    private var nearMountains: [(CGFloat, CGFloat)] {
        [(0, 1), (0, 0.70), (0.15, 0.50), (0.30, 0.68), (0.50, 0.35),
         (0.68, 0.65), (0.82, 0.45), (1, 0.70), (1, 1)]
    }

    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            let groundH = h * 0.18
            let charH = h * 0.36
            let visibleCount = min(flowers.count, 5 + bloom * 2)

            ZStack(alignment: .bottom) {
                skyLayer(size: geo.size)
                mountainsLayer(h: h)
                hillsLayer(h: h)
                groundLayer(groundH: groundH)
                flowersLayer(w: w, h: h, groundH: groundH, count: visibleCount, front: false)

                CharacterView(height: charH)
                    .position(x: w * characterX, y: h - groundH * 0.5 - charH / 2)

                flowersLayer(w: w, h: h, groundH: groundH, count: visibleCount, front: true)
            }
            .frame(width: w, height: h)
        }
    }

    private func skyLayer(size: CGSize) -> some View {
        ZStack {
            time.sky
            SkyBody(time: time, size: size)
            if time != .night {
                CloudView(sceneWidth: size.width, y: size.height * 0.12, scale: 1.0, seconds: 90)
                CloudView(sceneWidth: size.width, y: size.height * 0.24, scale: 0.7, seconds: 120)
            }
        }
    }

    private func mountainsLayer(h: CGFloat) -> some View {
        ZStack(alignment: .bottom) {
            MountainLayer(color: Color(hex: "C9D3EA"), tint: time.hillTint, points: farMountains)
                .frame(height: h * 0.66)
            MountainLayer(color: Color(hex: "AEBFE0"), tint: time.hillTint, points: nearMountains)
                .frame(height: h * 0.50)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
    }

    private func hillsLayer(h: CGFloat) -> some View {
        ZStack(alignment: .bottom) {
            HillLayer(color: GardenPalette.farHill, tint: time.hillTint,
                      amplitude: 30, wavelength: 700, phase: 0.5)
                .frame(height: h * 0.52)
            HillLayer(color: GardenPalette.midHill, tint: time.hillTint,
                      amplitude: 24, wavelength: 520, phase: 2.0)
                .frame(height: h * 0.42)
            HillLayer(color: GardenPalette.nearHill, tint: time.hillTint,
                      amplitude: 18, wavelength: 380, phase: 3.5)
                .frame(height: h * 0.36)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
    }

    private func groundLayer(groundH: CGFloat) -> some View {
        VStack(spacing: 0) {
            Rectangle().fill(GardenPalette.pathEdge).frame(height: 6)
            Rectangle().fill(GardenPalette.path)
        }
        .frame(height: groundH)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
    }

    private func flowersLayer(w: CGFloat, h: CGFloat, groundH: CGFloat, count: Int, front: Bool) -> some View {
        let visible = flowers.prefix(count).filter { ($0.depth > 0.75) == front }
        return ZStack {
            ForEach(visible) { spot in
                let size = h * 0.11 * spot.scale
                let baseY = (h - groundH) + groundH * (0.10 + 0.80 * spot.depth)
                PlantedFlower(size: size,
                              petal: FlowerSpot.petalColors[spot.colorIndex],
                              swayDuration: spot.duration)
                    .position(x: w * spot.x, y: baseY - size / 2)
            }
        }
        .frame(width: w, height: h)
    }
}

// MARK: - Buttons

struct SecondaryButton: View {
    let icon: String
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(GardenPalette.accent)
                Text(title)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .foregroundStyle(GardenPalette.text)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(GardenPalette.card, in: RoundedRectangle(cornerRadius: 20))
            .shadow(color: .black.opacity(0.08), radius: 6, y: 3)
        }
        .buttonStyle(PressableStyle())
        .accessibilityLabel(title)
    }
}

struct ButtonPanel: View {
    var onSelect: (HomeDestination) -> Void

    var body: some View {
        VStack(spacing: 14) {
            Button { onSelect(.play) } label: {
                HStack(spacing: 10) {
                    Image(systemName: "play.fill")
                    Text("Play")
                }
                .font(.system(size: 28, weight: .heavy, design: .rounded))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 18)
                .background(GardenPalette.accent, in: Capsule())
                .shadow(color: GardenPalette.accent.opacity(0.5), radius: 10, y: 6)
            }
            .buttonStyle(PressableStyle())
            .accessibilityLabel("Play")

            HStack(spacing: 12) {
                SecondaryButton(icon: "person.2.fill", title: "Players") { onSelect(.players) }
                SecondaryButton(icon: "book.fill", title: "Guide") { onSelect(.guide) }
                SecondaryButton(icon: "gearshape.fill", title: "Settings") { onSelect(.settings) }
            }
        }
    }
}

struct StreakChip: View {
    let days: Int

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: "leaf.fill").foregroundStyle(Color(hex: "5E9A52"))
            Text("\(days) of 7 days this week")
                .font(.system(.footnote, design: .rounded).weight(.semibold))
                .foregroundStyle(GardenPalette.text)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(GardenPalette.card, in: Capsule())
    }
}

// MARK: - Home screen

struct HomeView: View {
    @StateObject private var tracker = UsageTracker()
    @Environment(\.scenePhase) private var scenePhase

    var previewTime: TimeOfDay?
    var onSelect: (HomeDestination) -> Void

    init(previewTime: TimeOfDay? = nil,
         onSelect: @escaping (HomeDestination) -> Void = { _ in }) {
        self.previewTime = previewTime
        self.onSelect = onSelect
    }

    var body: some View {
        GeometryReader { geo in
            if geo.size.width > geo.size.height {
                landscapeLayout(geo.size)
            } else {
                portraitLayout(geo.size)
            }
        }
        .onAppear {
            if let t = previewTime { tracker.previewOverride = t }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active { tracker.refresh() }
        }
    }

    // Title text switches to white on the night sky so it stays readable.
    private var titleColor: Color {
        tracker.displayed == .night ? Color.white : GardenPalette.text
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Garden Path")
                .font(.system(size: 38, weight: .heavy, design: .rounded))
                .foregroundStyle(titleColor)
            Text("Move together. Grow together.")
                .font(.system(.subheadline, design: .rounded).weight(.medium))
                .foregroundStyle(titleColor.opacity(0.8))
            StreakChip(days: tracker.playedDaysThisWeek())
        }
    }

    // Portrait: scenery on top, buttons on the "ground" below it.
    private func portraitLayout(_ size: CGSize) -> some View {
        VStack(spacing: 0) {
            ZStack(alignment: .topLeading) {
                HomeScene(time: tracker.displayed,
                          bloom: tracker.playedDaysThisWeek(),
                          characterX: 0.30)
                    .ignoresSafeArea(edges: .top)
                header
                    .padding(.horizontal, 24)
                    .padding(.top, 12)
            }
            .frame(height: size.height * 0.60)

            ZStack {
                GardenPalette.path.ignoresSafeArea(edges: .bottom)
                ButtonPanel(onSelect: onSelect)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 20)
            }
        }
    }

    // Landscape: full-screen scenery, buttons in a panel on the right.
    private func landscapeLayout(_ size: CGSize) -> some View {
        ZStack {
            HomeScene(time: tracker.displayed,
                      bloom: tracker.playedDaysThisWeek(),
                      characterX: 0.27)
                .ignoresSafeArea()

            HStack(alignment: .top) {
                header
                Spacer(minLength: 24)
                ButtonPanel(onSelect: onSelect)
                    .padding(20)
                    .frame(width: min(380, size.width * 0.42))
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
                    .frame(maxHeight: .infinity, alignment: .center)
            }
            .padding(.horizontal, 28)
            .padding(.vertical, 16)
        }
    }
}

// MARK: - Previews

#Preview("Portrait") {
    HomeView()
}

#Preview("Landscape") {
    HomeView()
        .previewInterfaceOrientation(.landscapeLeft)
}

#Preview("Night") {
    HomeView(previewTime: .night)
}
