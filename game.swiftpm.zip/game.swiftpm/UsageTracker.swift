//
//  UsageTracker.swift
//  Tracks which days the game was played and turns that into the garden's
//  time of day (bright day / evening / night).
//
//  Needs `TimeOfDay` from GardenColors.swift.
//
//  HOW IT WORKS
//  - A day counts as "played" only when a session is completed, not just when
//    the app is opened (call recordSessionCompleted() after a real session).
//  - Each played day is saved as a date in UserDefaults. Everything stays on
//    the device, so it works offline.
//  - Regularity = how many of the last 7 days were played.
//        3 or more days  ->  bright day
//        1 or 2 days     ->  evening
//        0 days          ->  night
//    Counting days per week (not a consecutive streak) means rest days are fine.
//  - New users get bright day for their first `graceDays` days.
//

import Foundation
import SwiftUI

final class UsageTracker: ObservableObject {

    // Tune these three numbers to change the feel.
    private let graceDays = 7        // new users always see bright day
    private let dayThreshold = 3     // played days in last 7 for "day"
    private let keepHistoryDays = 30 // older records are dropped

    private let playedKey = "playedDays"
    private let firstLaunchKey = "firstLaunchDate"
    private let calendar = Calendar.current

    /// The mood based on real usage.
    @Published private(set) var timeOfDay: TimeOfDay = .day

    /// Set this (e.g. from a "preview the garden" button in settings) to show
    /// another mood without changing real usage data. Set to nil to go back.
    @Published var previewOverride: TimeOfDay? = nil

    /// What the background should actually show.
    var displayed: TimeOfDay { previewOverride ?? timeOfDay }

    init() {
        recordFirstLaunchIfNeeded()
        refresh()
    }

    // MARK: - Public

    /// Call this when the player finishes a real session (e.g. 2+ minutes).
    func recordSessionCompleted(on date: Date = Date()) {
        let today = calendar.startOfDay(for: date)
        var days = loadPlayedDays()
        if !days.contains(today) {
            days.append(today)
        }
        if let cutoff = calendar.date(byAdding: .day, value: -keepHistoryDays, to: today) {
            days = days.filter { $0 >= cutoff }
        }
        UserDefaults.standard.set(days, forKey: playedKey)
        refresh()
    }

    /// Recalculate the mood. Call when the app becomes active, since the date
    /// may have changed while it was in the background.
    func refresh(now: Date = Date()) {
        timeOfDay = computeTimeOfDay(now: now)
    }

    /// How many of the last 7 days were played (handy for showing "4 of 7 days").
    func playedDaysThisWeek(now: Date = Date()) -> Int {
        let today = calendar.startOfDay(for: now)
        guard let weekStart = calendar.date(byAdding: .day, value: -6, to: today) else { return 0 }
        return loadPlayedDays().filter { $0 >= weekStart && $0 <= today }.count
    }

    // MARK: - Private

    private func computeTimeOfDay(now: Date) -> TimeOfDay {
        let today = calendar.startOfDay(for: now)

        // Grace period: a brand-new user always starts with bright day.
        if let first = UserDefaults.standard.object(forKey: firstLaunchKey) as? Date {
            let daysSinceFirst = calendar.dateComponents([.day], from: first, to: today).day ?? 0
            if daysSinceFirst < graceDays {
                return .day
            }
        }

        let count = playedDaysThisWeek(now: now)
        if count >= dayThreshold { return .day }
        if count >= 1 { return .evening }
        return .night
    }

    private func loadPlayedDays() -> [Date] {
        UserDefaults.standard.array(forKey: playedKey) as? [Date] ?? []
    }

    private func recordFirstLaunchIfNeeded() {
        if UserDefaults.standard.object(forKey: firstLaunchKey) == nil {
            let today = calendar.startOfDay(for: Date())
            UserDefaults.standard.set(today, forKey: firstLaunchKey)
        }
    }
}

// MARK: - Example usage
//
//  struct GameRoot: View {
//      @StateObject private var tracker = UsageTracker()
//      @Environment(\.scenePhase) private var scenePhase
//
//      var body: some View {
//          ZStack {
//              GardenBackground(time: tracker.displayed)
//              // ... your game UI ...
//          }
//          .onChange(of: scenePhase) { phase in
//              if phase == .active { tracker.refresh() }
//          }
//      }
//  }
//
//  // When a session ends:
//  // tracker.recordSessionCompleted()
